Ice Wisp by schlossbauer on Thingiverse: https://www.thingiverse.com/thing:7221799

Summary:
Ice Wisp.You can go to https://www.patreon.com/Schlossbauer if you want earlier access our to sell my work.